cd /qhapp/tomcat/zktools
pwd
echo '#########################start#################### '>>batchdel.log
echo '********** '>>batchdel.log
echo `date` >> batchdel.log
echo '********** '>>batchdel.log
java -cp BatchZkManager-0.1-jar-with-dependencies.jar    cn.openlo.batchCheck.BatchCheck   1>> batchdel.log  2>>batchdel.log
 
echo '********** '>>batchdel.log
echo `date` >> batchdel.log
echo '********** '>>batchdel.log
java -cp BatchZkManager-0.1-jar-with-dependencies.jar cn.openlo.batchCheck.BatchBakClean   1>> batchdel.log  2>>batchdel.log

echo '********** '>>batchdel.log
echo `date` >> batchdel.log
echo '********** '>>batchdel.log
java -cp BatchZkManager-0.1-jar-with-dependencies.jar cn.openlo.csv2mysql.batchCsvImport    1>> batchdel.log  2>>batchdel.log


echo '********** '>>batchdel.log
echo `date` >> batchdel.log
echo '********** '>>batchdel.log
java -cp BatchZkManager-0.1-jar-with-dependencies.jar    cn.openlo.batchCheck.BatchDel  1>> batchdel.log  2>>batchdel.log
echo `date` >>batchdel.log
echo '########################end######################## '>>batchdel.log

echo '****rmlocks****** '>>batchdel.log
sh rmlocks.sh  >> batchdel.log
