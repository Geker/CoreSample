cd /qhapp/tomcat/zk01/zookeeper-3.5.2-alpha/bin
pwd
./zkCli.sh -server  10.60.80.78:22181 <<EOF
addauth digest ufozk:ufozk#2016
stat /_lo/openlo-batch-schedule/BatchGrp-batSvr/ExecutingTasks/locks
deleteall /_lo/openlo-batch-schedule/BatchGrp-batSvr/ExecutingTasks/locks
stat /_lo/openlo-batch-schedule/BatchGrp-batSvr/ExecutingTasks/locks
quit
EOF

