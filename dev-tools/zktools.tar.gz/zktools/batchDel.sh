echo ' '>>batchdel.log
echo ' '>>batchdel.log
echo `date` >> batchdel.log
echo 'start------------------------------------ '>>batchdel.log
java -cp BatchZkManager-0.1-jar-with-dependencies.jar    cn.openlo.batchCheck.BatchDel  1>> batchdel.log  2>>batchdel.log
echo `date` >>batchdel.log
echo 'end---------------------------------------'>>batchdel.log

