java -cp BatchZkManager-0.1-jar-with-dependencies.jar cn.openlo.batchCheck.BatchBakClean
